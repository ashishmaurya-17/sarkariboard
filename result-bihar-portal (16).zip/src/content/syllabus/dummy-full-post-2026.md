---
title: "Dummy Test Full-Length Post - 2026"
collection: "syllabus"
postDate: "2026-06-08"
summary: "This is a full-length dummy post for testing purposes within the syllabus tab. It contains all sections to ensure proper formatting and layout verification."
organization: "Dummy Organization"
state: "Central"
lastDateToApply: "2026-07-08"
examDate: "2026-08-01"
datesSchema:
  lastDateToApply: "2026-07-08"
  examDate: "2026-08-01"
  applicationStart: "2026-06-08"
urgent: true
---

## 🗓️ Important Dates
| Event | Date |
|:---|:---|
| Application Start | 2026-06-08 |
| Last Date to Apply | 2026-07-08 |
| Exam Date | 2026-08-01 |

## 💳 Examination Fee
| Category | Fee (Rs.) |
|:---|:---|
| Gen / OBC / EWS | Rs. 500 |
| SC / ST / PH / Women | Rs. 100 |

## 🎓 Eligibility Criteria
* **Educational Qualification:** Bachelor's Degree in any stream from a recognized university.
* **Age Limit:** 18-35 Years.

## 📋 Vacancy Details
* **Post Name:** Dummy Test Post
* **Total Posts:** Approx 1000

## 📌 How to Apply
1. Register on the official website.
2. Fill all personal details accurately.
3. Pay the application fee.
4. Upload all documents as per specified format.
5. Submit and take a printout.
