---
title: "Bihar BCECE Senior Resident / Tutor Document Verification List 2026"
collection: "results"
postDate: "2026-05-28"
summary: "Bihar Combined Entrance Competitive Examination Board (BCECEB) releases document verification and interview lists for Senior Resident and Tutor posts."
organization: "BCECE"
state: "Bihar"
datesSchema:
  lastDateToApply: "2026-05-28"
  examDate: "2026-05-20"
  applicationStart: "2026-04-10"
---

## 🏆 Selection Bulletins
Select candidates must attend interview with official certificates from medical council. Check your roll number below.
