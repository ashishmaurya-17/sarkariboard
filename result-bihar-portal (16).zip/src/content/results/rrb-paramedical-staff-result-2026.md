---
title: "Railway Recruiters Paramedical Staff CEN 04/2026 Merit Lists"
collection: "results"
postDate: "2026-05-20"
summary: "RRB Paramedical Staff CBT and Skill check results published. Check medical assistant merit ratings."
organization: "RRB"
state: "Central"
datesSchema:
  lastDateToApply: "2026-05-20"
  examDate: "2026-03-10"
  applicationStart: "2026-01-15"
---

## 🏆 Merit Outcome
Candidates verification list has been uploaded to local RRB portals.
