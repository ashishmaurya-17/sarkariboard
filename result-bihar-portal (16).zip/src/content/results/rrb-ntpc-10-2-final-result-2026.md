---
title: "Railway RRB NTPC (10+2) Under Graduate Under-Category Final Merit List 2026"
collection: "results"
postDate: "2026-05-22"
summary: "RRB NTPC 10+2 non-technical clerk selection results is released. Zone-wise cutoffs and final selected lists out."
organization: "RRB"
state: "Central"
datesSchema:
  lastDateToApply: "2026-05-22"
  examDate: "2025-11-20"
  applicationStart: "2024-09-10"
---

## 🏆 Selection Board Report
Check PDF results lists for selected under-graduate categories.
