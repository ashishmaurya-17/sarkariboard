---
title: "UPSSSC Lower Subordinate General Recruitment Examination 2026"
collection: "jobs"
postDate: "2026-04-20"
summary: "Uttar Pradesh Subordinate Services Selection Commission (UPSSSC) invites applications for competitive recruitment to vacant Lower Subordinate administrative posts in UP state departments."
organization: "UPSSSC"
state: "Uttar Pradesh"
lastDateToApply: "2026-05-30"
examDate: "Notify Later"
datesSchema:
  lastDateToApply: "2026-05-30"
  examDate: "Notify Later"
  applicationStart: "2026-04-20"
---

## 🗓️ Important Dates
| Event | Date |
|:---|:---|
| Application Start | 2026-04-20 |
| Last Date to Apply | 2026-05-30 |
| Exam Date | Notify Later |

## 💳 Examination Fee
| Category | Fee (Rs.) |
|:---|:---|
| Gen / OBC / EWS | Rs. 185 |
| SC / ST | Rs. 95 |
| PH Handicapped | Rs. 25 |

## 🎓 Eligibility Criteria
* Must have UPSSSC PET 2025 Score Card.
* Bachelor's Degree from a recognized board.
