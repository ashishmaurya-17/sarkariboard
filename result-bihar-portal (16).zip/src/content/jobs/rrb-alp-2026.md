---
title: "Railway RRB Assistant Loco Pilot ALP Online Registration 2026 (CEN 01/2026)"
collection: "jobs"
postDate: "2026-05-15"
summary: "Railway Recruitment Board (RRB) invites online applications for recruitment of Assistant Loco Pilots (ALP) under Centralised Employment Notice (CEN) No. 01/2026 in various railway zones across India."
organization: "RRB"
state: "Central"
lastDateToApply: "2026-06-14"
examDate: "September 2026"
datesSchema:
  lastDateToApply: "2026-06-14"
  examDate: "September 2026"
  applicationStart: "2026-05-15"
---

## 🗓️ Important Dates
| Event | Date / Details |
|:---|:---|
| Indicative Notification Released | 21.03.2026 |
| **Online Application Starts** | **15.05.2026 (00:00 Hrs)** |
| **Last Date to Apply Online** | **14.06.2026 (23:59 Hrs)** |
| Last Date for Fee Payment | 16.06.2026 (23:59 Hrs) |
| Application Modification Window | 17.06.2026 to 26.06.2026 (Fee Rs. 250) |
| CBT Stage 1 Exam Date | September 2026 |

## 🔗 Online Registration & Apply Links
| Action | Link Location |
|:---|:---|
| **Direct Apply Online Link** | [**Click here to Apply Online ⚡**](https://www.rrbapply.gov.in/#/auth/home) |
| Official RRB Apply Portal | [rrbapply.gov.in Portal 🔗](https://www.rrbapply.gov.in/#/auth/home) |

## 💳 Examination Fee
| Category | Fee (Rs.) | Refund Terms |
|:---|:---|:---|
| **General / OBC / EWS Candidates** | **Rs. 500** | Rs. 400 refunded (minus bank charges) after appearing in 1st Stage CBT |
| **SC / ST / Ex-Servicemen / Female / Transgender / Minorities / Economically Backward Class (EBC)** | **Rs. 250** | Rs. 250 refunded (minus bank charges) after appearing in 1st Stage CBT |

*Note: EBC annual family income must be less than Rs. 50,000 to avail of the concessional fee.*

## 📐 Medical Standards
| Medical Standard | General Fitness | Visual Standards |
|:---|:---|:---|
| **A-1** | Physically fit in all respects | • Distant Vision: 6/6, 6/6 without glasses with fogging test (must not accept +2D)<br>• Near Vision: Sn. 0.6, 0.6 without glasses<br>• Must pass Colour Vision, Binocular Vision, Field of Vision, Night Vision, & Mesopic Vision tests |

*Warning: Candidates who have undergone LASIK Surgery or any other corrective refractive operation are NOT eligible.*

## 🎓 Educational Qualification & Eligibility
* **Age Limit:** 18 to 30 Years as of **01-07-2026** (Age relaxation applicable as per official norms).
* **Essential Qualifications (Any of the following):**
  1. Matriculation / SSLC plus ITI from recognized NCVT/SCVT institutions in candidate trades (Fitter, Electrician, Instrument Mechanic, Millwright/Maintenance Mechanic, Mechanic (Radio & TV), Electronics Mechanic, Mechanic (Motor Vehicle), Wireman, Tractor Mechanic, Armature & Coil Winder, Mechanic (Diesel), Heat Engine, Turner, Machinist, Refrigeration & Air-Conditioning Mechanic).
  2. Matriculation / SSLC plus Course Completed Act Apprenticeship.
  3. 3 Years Diploma in Mechanical / Electrical / Electronics / Automobile Engineering from a recognized board/institution.
  4. B.E. / B.Tech Degree in the aforementioned Engineering disciplines.

## 📋 Vacancy Details
| Post Name | Pay Level | Initial Pay | Age Limit (01.07.2026) | Total Vacancies (All RRBs) |
|:---|:---|:---|:---|:---|
| **Assistant Loco Pilot (ALP)** | Level-2 | Rs. 19,900 | 18 – 30 Years | **11,127 Posts** |

### Zone-wise Vacancy Breakdown Highlights:
* **Bilaspur (SECR & CR):** 522 Posts
* **Bhubaneshwar (ECoR):** 801 Posts
* **Secunderabad (ECoR & SCR):** 1,420 Posts
* **Mumbai (CR, SCR, WR):** 1,193 Posts
* **Kolkata (ER & SER):** 841 Posts
* **Ajmer (NWR & WCR):** 718 Posts

## 📝 Recruitment & Examination Process
The recruitment process comprises 5 consecutive stages:
1. **First Stage CBT (CBT-1):** Screening test of 60 minutes containing 75 questions (75 marks). Negative marking @1/3rd marks applies.
2. **Second Stage CBT (CBT-2):** 2.5 hours containing 175 questions split into two parts:
   * **Part-A:** 90 minutes, 100 questions (Used for merit list preparation).
   * **Part-B:** 60 minutes, 75 questions (Trade qualifying test, minimum 35% required).
3. **Computer Based Aptitude Test (CBAT):** Candidates equal to 8 times vacancies are shortlisted. Must secure a minimum T-score of 42 in each test battery to qualify.
4. **Document Verification (DV)**
5. **Medical Examination (ME)**

## 📌 Step-by-Step Instructions on How to Apply
1. Click the [Direct Apply Online Link](https://www.rrbapply.gov.in/#/auth/home) to open the official RRB application page.
2. Select **Create an Account** if you are a first-time applicant or log in with your existing 2024/2025 credentials.
3. Authenticate using DigiLocker or Aadhaar verification for accelerated processing.
4. Fill out the application form carefully. Note that details entered in the 'Create an Account' form and your chosen RRB cannot be modified later.
5. Upload your live captured photograph and running handwriting signature as specified.
6. Submit the online application fee before the deadline.
7. Print out the final submission page for reference.
