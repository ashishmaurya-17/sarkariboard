---
title: "CBSE Central Teacher Eligibility Test CTET Sept 2026 Online Form"
collection: "jobs"
postDate: "2026-05-10"
summary: "Central Board of Secondary Education (CBSE) invites online applications for the Central Teacher Eligibility Test (CTET) September 2026 session for Primary and Junior level teacher eligibility."
organization: "CBSE"
state: "Central"
lastDateToApply: "2026-06-15"
examDate: "2026-09-20"
datesSchema:
  lastDateToApply: "2026-06-15"
  examDate: "2026-09-20"
  applicationStart: "2026-05-10"
featured: true
---

## 🗓️ Important Dates
| Event | Date |
|:---|:---|
| Application Start Date | 2026-05-10 |
| Last Date to Apply Online | 2026-06-15 |
| Exam Date | 2026-09-20 |
| Result Declared | October 2026 |

## 💳 Examination Fee
| Category | Single Paper Fee | Both Papers Fee |
|:---|:---|:---|
| General / OBC | Rs. 1000 | Rs. 1200 |
| SC / ST / PH | Rs. 500 | Rs. 600 |

## 🎓 Eligibility Criteria
* **Primary Stage (Class I-V):** Senior Secondary with at least 50% marks and 2-year Diploma in Elementary Education / Bachelor of Elementary Education (B.El.Ed).
* **Elementary Stage (Class VI-VIII):** Graduation and 2-year Diploma in Elementary Education / B.Ed / B.El.Ed.

## 📋 Vacancy Details
Teacher eligibility certification for teachers across national and state government academic institutions.

## 📌 How to Apply
1. Register on the official CTET website.
2. Fill out Paper-1, Paper-2, or both choice forms.
3. Upload essential documents.
