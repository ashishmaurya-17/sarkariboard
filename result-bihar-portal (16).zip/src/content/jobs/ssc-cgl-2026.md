---
title: "SSC CGL Combined Graduate Level Recruitment Examination 2026"
collection: "jobs"
postDate: "2026-05-18"
summary: "Staff Selection Commission (SSC) invites applications for the Combined Graduate Level (CGL) 2026 for Group B and Group C assistant posts in multiple ministries and departments."
organization: "SSC"
state: "Central"
lastDateToApply: "2026-06-18"
examDate: "2026-08-25"
datesSchema:
  lastDateToApply: "2026-06-18"
  examDate: "2026-08-25"
  applicationStart: "2026-05-18"
urgent: true
---

## 🗓️ Important Dates
| Event | Date |
|:---|:---|
| Application Start | 2026-05-18 |
| Last Date to Apply | 2026-06-18 |
| Tier-1 Exam | August 2026 |

## 💳 Examination Fee
| Category | Fee (Rs.) |
|:---|:---|
| Gen / OBC / EWS | Rs. 100 |
| SC / ST / PH / Women | Rs. 0 |

## 🎓 Eligibility Criteria
* **Educational Qualification:** Bachelor's Degree in any stream.
* **Age Limit:** 18-30 Years (Post-wise variation).

## 📋 Vacancy Details
* **Assistant Audit Officer, Section Officers, Inspectors, Sub-Inspectors:** Approx 15,000 vacant seats.

## 📌 How to Apply
1. Apply online via ssc.gov.in.
2. Verify structural details and photo guidelines matching new GSC standards.
