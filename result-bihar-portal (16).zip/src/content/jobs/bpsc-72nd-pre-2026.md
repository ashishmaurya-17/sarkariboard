---
title: "BPSC 72nd Combined Competitive Exam (Prelims) Recruitment 2026"
collection: "jobs"
postDate: "2026-05-25"
summary: "Bihar Public Service Commission (BPSC) announces the 72nd Combined Competitive Examination (Prelims) 2026 for recruitment to various civil services and administrative posts."
organization: "BPSC"
state: "Bihar"
lastDateToApply: "2026-06-25"
examDate: "2026-08-10"
datesSchema:
  lastDateToApply: "2026-06-25"
  examDate: "2026-08-10"
  applicationStart: "2026-05-25"
urgent: true
featured: true
---

## 🗓️ Important Dates
| Event | Date |
|:---|:---|
| Application Start Date | 2026-05-25 |
| Last Date to Apply Online | 2026-06-25 |
| Last Date for Fee Payment | 2026-06-25 |
| Prelims Exam Date | 2026-08-10 |
| Admit Card Available | August 2026 |

## 💳 Examination Fee
| Category | Fee (Rs.) |
|:---|:---|
| General / OBC / Other State | Rs. 600 |
| SC / ST / PH of Bihar | Rs. 150 |
| Female Candidates of Bihar | Rs. 150 |

## 🎓 Eligibility Criteria
* **Age Limit:** 20, 21 or 22 to 37 Years (Male) & 40 Years (Female) as of 01-08-2026. Age relaxation applicable as per BPSC rules.
* **Educational Qualification:** Bachelor's Degree in any stream from a recognized University in India.

## 📋 Vacancy Details
* **Administrative Officers:** 250 Posts
* **Bihar Police Service (DSP):** 45 Posts
* **Tehsildar / Block Development Officer:** 120 Posts
* **Other Departmental Posts:** 185 Posts
* **Total Vacancy:** 600 Posts

## 📌 How to Apply
1. Go to the official BPSC website (bpsc.bih.nic.in).
2. Click on the Online Application portal.
3. Complete the registration forms with your educational credentials.
4. Upload personal documents, passport size photo, and signature.
5. Pay the exam fees online or offline as requested.
6. Verify all details and print the confirmation page for your records.
